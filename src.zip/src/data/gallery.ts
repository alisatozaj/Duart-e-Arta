// TODO: replace '/about-1.jpg' with real photos, e.g. '/gallery/dhoma-1.jpg'
export const categories = [
  { id: 'all', label: 'Të gjitha' },
  { id: 'dhomat', label: 'Dhomat' },
  { id: 'aktivitete', label: 'Aktivitete' },
  { id: 'kopshti', label: 'Kopshti' },
  { id: 'ushqimi', label: 'Ushqimi' },
];

export const photos = [
  { src: '/about-1.jpg', category: 'dhomat', caption: 'Dhoma të rehatshme', alt: 'Një dhomë e rehatshme në Duart e Arta' },
  { src: '/about-1.jpg', category: 'dhomat', caption: 'Ambienti i përbashkët', alt: 'Ambienti i përbashkët i qendrës' },
  { src: '/about-1.jpg', category: 'aktivitete', caption: 'Aktivitete së bashku', alt: 'Banorët gjatë një aktiviteti' },
  { src: '/about-1.jpg', category: 'aktivitete', caption: 'Muzikë dhe lojëra', alt: 'Banorët gjatë një ore muzike' },
  { src: '/about-1.jpg', category: 'aktivitete', caption: 'Kohë dhe kujdes', alt: 'Një banore së bashku me kujdestaren' },
  { src: '/about-1.jpg', category: 'kopshti', caption: 'Kopshti ynë', alt: 'Kopshti i qendrës' },
  { src: '/about-1.jpg', category: 'kopshti', caption: 'Shëtitje jashtë', alt: 'Banorët gjatë një shëtitjeje' },
  { src: '/about-1.jpg', category: 'ushqimi', caption: 'Vakte të freskëta', alt: 'Një vakt i përgatitur në qendër' },
  { src: '/about-1.jpg', category: 'ushqimi', caption: 'Tavolina e përbashkët', alt: 'Banorët në tavolinë' },
];